To run the code, all you have to do is type the following in the terminal:
make

This will create the files necessary after compiling them
./serverExe {port number}
./clientExe localhost {port number}

You will be able to see what the server responds on the server run and what the client needs to do on the client side
The program on the client side is closed after every game and the results will be printed.
